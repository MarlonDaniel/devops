<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_reportbuilder', language 'es_wp', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_reportbuilder
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accesspeoplecapabilities'] = 'Los usuarios con capacidad a nivel de Sistema para ver/ gestionar reportes pueden ver este reporte para TODOS los usuarios';
$string['accesstab'] = 'Acceso';
$string['actions'] = 'Acciones';
$string['addacondition'] = 'Agregar una condición...';
$string['addafilter'] = 'Agregar un filtro...';
$string['addcolumn'] = 'Agregar columna';
$string['adddefault'] = 'Incluir la configuración por defecto';
$string['adddefault_help'] = 'La fuente de datos provee un conjunto de columnas, condiciones y filtros por defecto. Marque esta casilla si desea que el informe incluya inicialmente estas configuraciones.';
$string['addreport'] = 'Nuevo reporte';
$string['addschedule'] = 'Nueva planificación';
$string['aggregation_avg'] = 'Promedio';
$string['aggregation_count'] = 'Conteo';
$string['aggregation_countdistinct'] = 'Conteo de valores únicos';
$string['aggregation_max'] = 'Máximo';
$string['aggregation_min'] = 'Mínimo';
$string['aggregation_percent'] = 'Porcentaje';
$string['aggregation_sum'] = 'Suma';
$string['aggregation_unique'] = 'Valores únicos';
$string['and'] = 'Y';
$string['audience'] = 'Audiencia';
$string['audiencejobadd'] = 'Agregar Tarea';
$string['audiencejobremove'] = 'Eliminar Tarea';
$string['audiencejobs'] = 'Tareas';
$string['conditiondatastorecoursefullname'] = 'Nombre completo del curso en el almacén';
$string['conditiondatastoreuserfirstname'] = 'Nombre del usuario en el almacén';
$string['conditiondatastoreuserlastname'] = 'Apellido del usuario en el almacén';
$string['conditionstab'] = 'Condiciones';
$string['customreports'] = 'Reportes a medida';
$string['debugsqlquery'] = 'Consulta SQL actual';
$string['deletefilter'] = 'Eliminar filtro';
$string['deletereport'] = 'Eliminar reporte';
$string['duplicate'] = 'Duplicar';
$string['duplicatereport'] = 'Duplicar reporte';
$string['editreportname'] = 'Editar el nombre del reporte';
$string['entitydatastoreaction'] = 'Acción del Almacén de datos';
$string['entitydatastorecourse'] = 'Curso del Almacén de datos';
$string['entitydatastoreuser'] = 'Usuario del Almacén de datos';
$string['entityuser'] = 'Usuario';
$string['error:mustselectsource'] = 'Debe seleccionar una fuente de datos.';
$string['filtersbutton'] = 'Mostrar/ ocultar la barra de filtros';
$string['filterstab'] = 'Filtros';
$string['fullnamewithlink'] = 'Nombre completo con link al perfil';
$string['fullnamewithpicture'] = 'Nombre completo con imagen';
$string['fullnamewithpicturelink'] = 'Nombre completo con imagen y link al perfil';
$string['jobdepartment'] = 'Departamento';
$string['managereports'] = 'Gestionar reportes a medida';
$string['movecolumn'] = 'Mover la columna {$a}';
$string['movefilter'] = 'Mover el filtro \'{$a}\\';
$string['movesorting'] = 'Move sorting order of column \'{$a}\\';
$string['myreports'] = 'Mis Reportes';
$string['never'] = 'Nunca';
$string['newaggregationfor'] = 'New aggregation for the column \'{$a}\\';
$string['newschedule'] = 'Nueva planificación';
$string['newvaluefor'] = 'Nuevo valor para \'{$a}\\';
$string['noaggregation'] = 'Sin agregación';
$string['nocolumnsselected'] = 'Agregar una columna al reporte';
$string['nofilters'] = 'No hay filtros seleccionados';
$string['numberanyvalue'] = 'Cualquier valor';
$string['numberequalorgreaterthan'] = 'Mayor o igual';
$string['numberequalorlessthan'] = 'Menor o igual';
$string['numberequalto'] = 'Igual';
$string['pluginname'] = 'Editor de reportes';
$string['position'] = 'Posición';
$string['privacy:metadata:reportbuilder:source'] = 'La fuente de datos del reporte';
$string['profiledepartment'] = 'Departamento según perfil';
$string['reportcoursecompletion'] = 'Completud de curso del Almacén';
$string['reportname'] = 'Nombre del Reporte';
$string['reportsource'] = 'Fuente de datos';
$string['reportsource_help'] = 'La fuente de datos define desde dónde se tomará la información para construir el reporte';
$string['reportstab'] = 'Reportes';
$string['reportuserslist'] = 'Lista de usuarios';
$string['resetall'] = 'Reiniciar todos';
$string['resetallconditions'] = 'Reiniciar todas las condiciones';
$string['schedulesstab'] = 'Planificaciones';
$string['selectaggregation'] = 'Elija una agregación para la columna \'{$a}\\';
$string['selectsource'] = 'Elija una fuente de datos';
$string['startdate'] = 'Fecha de inicio';
$string['tabletab'] = 'Tabla';
$string['userconfirmed'] = 'Usuario confirmado';
$string['userpicture'] = 'Imagen del usuario';
$string['usersuspended'] = 'Usuario suspendido';
