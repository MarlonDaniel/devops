<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_organisation', language 'es_wp', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_organisation
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actions'] = 'Acciones';
$string['addjob'] = 'Nueva tarea';
$string['addjobforuser'] = 'Nueva tarea para \'{$a}\\';
$string['addpositionframework'] = 'Nueva estructura de puestos';
$string['anydepartment'] = 'Cualquier';
$string['anyposition'] = 'Cualquier';
$string['audienceand'] = 'Y';
$string['audienceor'] = 'O';
$string['audienceusersall'] = 'Todos los usuarios';
$string['conditioncanviewreports'] = 'Puede ver Reportes';
$string['department'] = 'Departmento';
$string['departmentandpositionrequiredforjobcreate'] = 'Es necesario crear departamentos y puestos antes de avanzar con la asignación de tareas';
$string['departmentdescription'] = 'Descripción';
$string['departmentframework'] = 'Estructura de departamentos';
$string['departmentframeworks'] = 'Estructuras de departamentos';
$string['department_help'] = 'Departamento donde se desempeña la tarea';
$string['departmentidnumber'] = 'Número de ID';
$string['departmentmanager'] = 'Gestor del Departamento';
$string['departmentname'] = 'Nombre';
$string['departmentnotfound'] = 'Departmento no encontrado';
$string['departments'] = 'Departmentos';
$string['details'] = 'Detalles';
$string['editdepartment'] = 'Editar departmento \'{$a}\\';
$string['editdepartmentframework'] = 'Editar estructura de departamentos \'{$a}\\';
$string['editdepartmentname'] = 'Editar nombre';
$string['editjob'] = 'Editar Tarea';
$string['editjobforuser'] = 'Editar Tarea para \'{$a}\\';
$string['editposition'] = 'Editar puesto \'{$a}\\';
$string['editpositionframework'] = 'Editar estructura de puestos \'{$a}\\';
$string['editpositionname'] = 'Editar nombre';
$string['enddate'] = 'Fecha de fin';
$string['enddate_help'] = 'Fecha de fin de la tarea asignada';
$string['entitydepartment'] = 'Departmento';
$string['entityjob'] = 'Tarea';
$string['entityposition'] = 'Puesto';
$string['fullcompletionreport'] = 'Reporte de completudes';
$string['fullname'] = 'Usuario';
$string['globalmanagementicons'] = 'Íconos de gestión general';
$string['globalmanager'] = 'Gestor general';
$string['globalmanager_help'] = 'La persona con el rol de Gestor General será considerado como gestor de cualquiera en una posición inferior, sin importar a qué departamento pertenezca.';
$string['jobdeleteconfirm'] = 'Are you sure you want to delete this job and all associated data? This action cannot be undone.';
$string['jobs'] = 'Asignaciones de Tareas';
$string['jobsnumber'] = 'Asignaciones';
$string['jobsnumber_help'] = 'Muestra la cantidad de asignaciones de este puesto, actuales y pasadas.<br /> Por ejemplo, \'10 (2)\' significa que hay 10 asignaciones activas y 2 caducas.';
$string['jobstartdateafter'] = 'El trabajo comienza en o después de';
$string['movedepartmentframework'] = 'Mover la estructura de departamentos \'{$a}\\';
$string['movepositionframework'] = 'Mover la estructura de puestos \'{$a}\\';
$string['myteams'] = 'Equipos';
$string['notification'] = 'Notificación';
$string['organisationadmintab'] = 'Organización';
$string['organisation:allocateuserstoprogramcertificationsdept'] = 'Inscribir usuarios en Programas y Certificaciones';
$string['organisation:allocateuserstoprogramcertificationsdept_help'] = 'Gestor de Departamento: Inscribir usuarios en Programas y Certificaciones';
$string['organisation:allocateuserstoprogramcertificationsglob'] = 'Inscribir usuarios en Programas y Certificaciones';
$string['organisation:allocateuserstoprogramcertificationsglob_help'] = 'Gestor General: Inscribir usuarios en Programas y Certificaciones';
$string['organisation:receivenotificationsdept'] = 'Recibir notificaciones';
$string['organisation:receivenotificationsdept_help'] = 'Gestor de Departamento: Recibir notificaciones';
$string['organisation:receivenotificationsglob'] = 'Recibir notificaciones';
$string['organisation:receivenotificationsglob_help'] = 'Gestor General: Recibir notificaciones';
$string['organisation:viewusersreportdept'] = 'Ver reportes de usuarios';
$string['organisation:viewusersreportdept_help'] = 'Gestor de Departamento: Ver reportes de usuarios';
$string['organisation:viewusersreportglob_help'] = 'Gestor General: Ver reportes de usuarios';
$string['orgstructure'] = 'Estructura de la organización';
$string['pluginname'] = 'Estructura de la organización';
$string['position'] = 'Puesto';
$string['positiondescription'] = 'Descripción';
$string['positionframework'] = 'Estructura de puestos';
$string['positionframeworks'] = 'Estructuras de puestos';
$string['position_help'] = 'Elija el puesto';
$string['positionname'] = 'Nombre';
$string['positions'] = 'Puestos de trabajo';
$string['privacy:metadata:startdate'] = 'Cuando este trabajo inicia';
$string['showjobs'] = 'Mostrar Tareas';
$string['showpastjobs'] = 'Mostrar tareas pasadas';
$string['startdate'] = 'Fecha de inicio';
$string['startdate_help'] = 'Fecha de inicio de la tarea';
$string['usernotfound'] = 'Usuario no encontrado';
$string['users'] = 'Elegir usuarios';
$string['users_help'] = 'Buscar y elegir usuarios para asignar a la tarea';
$string['validationmsgedateonsdate'] = 'La fecha de fin debe ser posterior a la fecha de inicio';
$string['withoutpermission'] = 'Sin el permiso \'{$a}\\';
$string['withpermission'] = 'Con el permiso \'{$a}\\';
$string['withsubdepartments'] = 'Incluir departamentos por debajo';
$string['withsubpositions'] = 'Incluir puestos por debajo';
