<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_certificate', language 'es_wp', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_certificate
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcertpage'] = 'Agregar página';
$string['addelement'] = 'Agregar elemento';
$string['aligncentre'] = 'Centrado';
$string['alignleft'] = 'Izquierda';
$string['alignment'] = 'Alineación de texto';
$string['alignright'] = 'Derecha';
$string['certificate'] = 'Certificado';
$string['certificate:manage'] = 'Gestionar certificados';
$string['certificates'] = 'Certificados';
$string['certificatesissued'] = 'Certificados emitidos';
$string['code'] = 'Código';
$string['createtemplate'] = 'Nueva plantilla de certificados';
$string['customfield_previewvalue'] = 'Previsualizar el valor';
$string['customfield_visible'] = 'Visible';
$string['deleteelement'] = 'Eliminar elemento';
$string['deletepage'] = 'Eliminar página';
$string['duplicate'] = 'Duplicar';
$string['editcertificate'] = 'Editar la plantilla de certificados  \'{$a}\\';
$string['editcontent'] = 'Editar el contenido';
$string['editdetails'] = 'Editar detalles';
$string['editelement'] = 'Editar \'{$a}\\';
$string['editelementname'] = 'Editar el nombre del elemento';
$string['editpage'] = 'Editar página {$a}';
$string['edittemplatename'] = 'Editar nombre de la plantilla';
$string['elementname'] = 'Nombre del elemento';
$string['elementwidth'] = 'Ancho en mm';
$string['entitycertificate'] = 'Certificado';
$string['eventcertificateissued'] = 'Certificado emitido';
$string['eventcertificaterevoked'] = 'Certificados revocados';
$string['eventtemplatecreated'] = 'Plantilla creada';
$string['eventtemplatedeleted'] = 'Plantilla eliminada';
$string['eventtemplateupdated'] = 'Plantilla actualizada';
$string['expired'] = 'Vencido';
$string['expiredcertificate'] = 'Este certificado venció';
$string['expires'] = 'Vence el';
$string['font'] = 'Fuente';
$string['fontcolour'] = 'Color';
$string['fontcolour_help'] = 'Color de la fuente';
$string['font_help'] = 'La fuente utilizada para la generación de este elemento';
$string['fontsize'] = 'Tamaño en pt';
$string['fontsize_help'] = 'El tamaño de la fuente en puntos.';
$string['hideshow'] = 'Mostrar/ ocultar';
$string['invalidelementwidth'] = 'Por favor ingrese un número positivo';
$string['invalidmargin'] = 'El margen debe ser mayor a cero.';
$string['invalidwidth'] = 'El ancho debe ser mayor a cero.';
$string['issuedon'] = 'Emitido el';
$string['issuenewcertificate'] = 'Emitir nuevo certificado a partir de esta plantilla';
$string['issuenewcertificates'] = 'Emitir nuevos certificados';
$string['leftmargin'] = 'Margen izquierdo en mm';
$string['leftmargin_help'] = 'Este es el margen izquierdo del PDF del certificado, en milímetros.';
$string['managetemplates'] = 'Gestionar las plantillas de certificados';
$string['mycertificates'] = 'Mis certificados';
$string['name'] = 'Nombre';
$string['notverified'] = 'No verificado';
$string['outcomecertificate'] = 'Emitir certificado';
$string['outcomecertificatedescription'] = 'Emitir el certificado \'{$a}\' a los usuarios';
$string['page'] = 'Página {$a}';
$string['pageheight'] = 'Altura de la página en mm';
$string['pagewidth'] = 'Ancho de la página en mm';
$string['pluginname'] = 'Certificado';
$string['posx'] = 'Posición X en mm';
$string['posy'] = 'Posición Y en mm';
$string['privacy:metadata:tool_certificate_issues:templateid'] = 'El ID del certificado';
$string['reg_wpcertificates'] = 'Cantidad de certificados ({$a})';
$string['reg_wpcertificatesissues'] = 'Cantidad de certificados emitidos ({$a})';
$string['revoke'] = 'Revocar';
$string['rightmargin'] = 'Margen derecho en mm';
$string['rightmargin_help'] = 'Margen derecho del certificado en PDF, en milímetros.';
$string['selectcertificate'] = 'Seleccionar certificado';
$string['type'] = 'Tipo';
$string['uploadimage'] = 'Subir imagen';
$string['verify'] = 'Verificar';
$string['verifycertificates'] = 'Verificar certificados';
$string['viewcertificate'] = 'Ver certificado';
