<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_certification', language 'es_wp', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_certification
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actions'] = 'Acciones';
$string['activecertifications'] = 'Certificaciones activas';
$string['afterstartdate'] = 'Después de la fecha de inicio';
$string['afterstartdatewithrelativedate'] = '{$a}  después de la fecha de inicio';
$string['allocationstartdate'] = 'Fecha de comienzo de las asignaciones';
$string['allocationwindowstartdate'] = 'Fecha de inicio';
$string['allocationwindowstartdate_help'] = 'Fecha de inicio para la ventana de asignaciones';
$string['archivedcertifications'] = 'Certificaciones archivadas';
$string['autocreategroupsasinprogram'] = 'Tal como está definido en el programa';
$string['certification:configurecustomfields'] = 'Configurar los campos custom de las certificaciones';
$string['certifications'] = 'Certificaciones';
$string['certificationscustomfield'] = 'Campos custom de las certificaciones';
$string['conditionrecertificationgraceperiod'] = 'El período de gracia para la re-certificación finaliza';
$string['conditionrecertificationstarted'] = 'Periodo de re-certificación iniciado';
$string['conditionrecertificationstarteddescription'] = 'Usuarios que han comenzado un período de re-certificación en la certificación \'{$a->fullname}\\';
$string['conditionrecertificationstarteddescriptionwithdate'] = 'Usuarios que han comenzado un período de re-certificación en la certificación \'{$a->fullname}\\<br />
Re-certificación iniciada en  \'{$a->conditiondate} o después\\';
$string['erroralreadycertified'] = 'El usuario ya fue certificado en esta certificación y con esta fecha de inicio';
$string['errorinvalidpaststartdate'] = 'La fecha de inicio no puede ser en el pasado';
$string['eventrecertificationgraceperiodended'] = 'Periodo de gracia para la re-certificación finalizado';
$string['eventrecertificationstarted'] = 'Re-certificación iniciada';
$string['outcomeallocation'] = 'Asignar usuarios a certificaciones';
$string['outcomeallocationdescription'] = 'Asignar usuarios a la certificación {$a}<br />
Mantener la fecha de inicio por defecto de la certificación';
$string['outcomeallocationdescriptionwithdate'] = 'Asignar usuarios a la certificación {$a->certificationname}<br />
Fecha de inicio de la certificación: \'{$a->startdate}\\';
$string['pluginname'] = 'Certificaciones';
$string['recertification'] = 'Re-certificación';
$string['recertificationgraceperiodendsonorbefore'] = 'El período de gracia para la re-certificación finaliza el';
$string['recertificationprogram'] = 'Programa de re-certificación';
$string['recertificationstartdate'] = 'Fecha de inicio de la re-certificación';
$string['recertificationstartedonorafter'] = 'Re-certificación iniciada en o después de';
$string['recertstartdaterelative'] = 'Fecha de inicio';
$string['recertstartdaterelative_help'] = 'Esta es la fecha en la cual el programa de re-certificación comenzará a estar disponible para el usuario.';
$string['startdate'] = 'Fecha de inicio';
$string['startdate_help'] = 'Fecha de inicio de la certificación';
$string['tagarea_tool_certification'] = 'Certificaciones';
$string['userstartdate'] = 'Fecha de inicio';
$string['userstartdate_help'] = 'Elija la fecha en la que este usuario podrá iniciar la certificación. Esta fecha sólo será aplicada a este usuario.';
