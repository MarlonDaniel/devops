<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_tenant', language 'es_wp', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_tenant
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accent'] = 'Accent';
$string['activetenants'] = 'Sitios activos';
$string['addtenant'] = 'Agregar sitio';
$string['adduser'] = 'Nuevo usuario';
$string['admin'] = 'Administrador';
$string['administrators'] = 'Administradores';
$string['advanced'] = 'Avanzadas';
$string['allocateusers'] = 'Asignar usuarios';
$string['archivedtenants'] = 'Sitios archivados';
$string['archivetenant'] = 'Archivar sitio';
$string['assigntenantadmins'] = 'Asignar el rol de Administrador de Sitio';
$string['basicinformation'] = 'Información básica';
$string['brand'] = 'Barra de navegación';
$string['brand_help'] = 'El color utilizado para la barra de navegación superior.';
$string['button'] = 'Botones primarios';
$string['button_help'] = 'El color de los botones principales.';
$string['category'] = 'Categoría de cursos';
$string['colours'] = 'Colores';
$string['confirmunassigntenantadmins'] = '¿Está seguro de revocar el rol de Administrador de Sitio para los usuarios seleccionados?';
$string['confirmunsuspenduser'] = '¿Está seguro de reactivar este usuario?';
$string['confirmunsuspendusers'] = '¿Está seguro de reactivar los usuarios seleccionados?';
$string['customcss'] = 'CSS adicional';
$string['defaultname'] = 'Sitio por defecto';
$string['deletetenant'] = 'Eliminar Sitio';
$string['deleteuser'] = 'Eliminar usuario';
$string['deleteusers'] = 'Eliminar usuarios';
$string['drawer'] = 'Menú lateral';
$string['drawer_help'] = 'El color utilizado para el fondo del menú lateral.';
$string['drawertext'] = 'Texto del menú lateral';
$string['editdetails'] = 'Editar detalles';
$string['edittenant'] = 'Editar el Sitio \'{$a}\\';
$string['edittenantname'] = 'Editar el nombre';
$string['edituser'] = 'Editar cuenta de usuario';
$string['edituserwithname'] = 'Editar el usuario \'{$a}\\';
$string['enrolwithoutgroups'] = 'Este curso no está en el modo de grupos separados.  Todos los usuarios se verán entre sí aún cuando pertenezcan a diferentes Sitios.';
$string['footer'] = 'Pie de página';
$string['footer_help'] = 'El color utilizado para el fondo del pie de página.';
$string['footertext'] = 'Texto del pie de página';
$string['headerlogo'] = 'Logo del encabezado';
$string['idnumber'] = 'Número de ID';
$string['loginbackground'] = 'Imagen de fondo para el Ingreso';
$string['loginlogo'] = 'Logo para el ingreso';
$string['loginurl'] = 'URL de ingreso';
$string['managetenants'] = 'Gestionar sitios';
$string['managetheme'] = 'Personalización del Sitio';
$string['managethemewpmenu'] = 'Sitio';
$string['name'] = 'Nombre del sitio';
$string['newname'] = 'Nuevo Sitio \'{$a}\\';
$string['newnamefor'] = 'Nuevo nombre para \'{$a}\\';
$string['nocategory'] = 'Sin categoría propia';
$string['notspecified'] = 'Sin definir';
$string['organisationadmintab'] = 'Organización';
$string['pluginname'] = 'Multisitio';
$string['privacy:metadata:user:tenantid'] = 'Sitio';
$string['separatetenantsingroups'] = 'En cursos compartidos entre más de un Sitio, agregar los usuarios de cada uno dentro de grupos separados.';
$string['sitename'] = 'Nombre completo del Sitio';
$string['sitename_help'] = 'Permite reescribir el nombre global para los usuarios de este Sitio';
$string['siteshortname'] = 'Nombre corto del Sitio';
$string['siteshortname_help'] = 'Permite reescribir el nombre corto global para los usuarios de este Sitio';
$string['suspenduser'] = 'Suspender usuario';
$string['suspendusers'] = 'Suspender usuarios';
$string['tenantadmin'] = 'Administrador de Sitio';
$string['tenantadministration'] = 'Administración de Sitio';
$string['tenantadministrator'] = 'Este usuarios es un administrador de Sitio';
$string['tenantdetails'] = 'Detalles';
$string['tenantmanager'] = 'Gestor de Sitio';
$string['tenants'] = 'Sitios';
$string['unassigntenantadmins'] = 'Revocar el rol de Administrador de Sitio';
$string['unsuspenduser'] = 'Reactivar usuario';
$string['unsuspendusers'] = 'Reactivar usuarios';
$string['userscount'] = 'Usuarios';
$string['viewusers'] = 'Gestionar el Sitio \'{$a}\\';
